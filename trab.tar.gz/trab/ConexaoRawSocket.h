

int ConexaoRawSocket(char *device);